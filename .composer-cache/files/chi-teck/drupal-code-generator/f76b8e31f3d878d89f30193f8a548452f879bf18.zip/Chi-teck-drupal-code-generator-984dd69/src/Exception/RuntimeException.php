<?php

declare(strict_types=1);

namespace DrupalCodeGenerator\Exception;

/**
 * The runtime exception for DCG commands.
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface {

}
