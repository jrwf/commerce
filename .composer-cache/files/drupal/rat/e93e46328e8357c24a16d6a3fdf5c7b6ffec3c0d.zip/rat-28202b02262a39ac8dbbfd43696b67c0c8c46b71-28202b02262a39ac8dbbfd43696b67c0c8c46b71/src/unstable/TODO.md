## Todo

- Add concrete builders like Image
- Still allow setProperty, to add ad-hoc stuff
- Should not break BC to 2.0

## Todo in ecosystem

- Add PhpdDoc
- Add docs
- Release
- Link Phpdoc and add docs
- Add docs page "Don't mess with #access"
- Move on IEF access issue and release issue
- Broaden sec issue
