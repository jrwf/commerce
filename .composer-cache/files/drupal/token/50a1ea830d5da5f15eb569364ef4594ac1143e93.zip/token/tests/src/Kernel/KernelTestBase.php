<?php

namespace Drupal\Tests\token\Kernel;

@\trigger_error('The ' . __NAMESPACE__ . '\KernelTestBase class is deprecated in token:8.x-1.14 and is removed from token:2.0.0. Use \Drupal\Tests\token\Kernel\TokenKernelTestBase instead. See https://www.drupal.org/node/3440940', E_USER_DEPRECATED);

/**
 * Helper test class with some added functions for testing.
 *
 * @deprecated in token:8.x-1.14 and is removed from token:2.0.0. Use
 *   \Drupal\Tests\token\Kernel\TokenKernelTestBase instead.
 *
 * @see https://www.drupal.org/node/3440940
 */
abstract class KernelTestBase extends TokenKernelTestBase {
}
