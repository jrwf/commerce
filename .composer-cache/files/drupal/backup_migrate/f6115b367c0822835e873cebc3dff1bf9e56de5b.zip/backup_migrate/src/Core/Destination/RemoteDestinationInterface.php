<?php

namespace Drupal\backup_migrate\Core\Destination;

/**
 * An interface for managing remote destinations.
 *
 * @package Drupal\backup_migrate\Core\Destination
 */
interface RemoteDestinationInterface extends DestinationInterface {

}
