<?php

/**
 * @file
 * A database agnostic dump for testing purposes.
 */

require __DIR__ . '/container_migrate_settings.php';
require __DIR__ . '/container_migrate_containers.php';
