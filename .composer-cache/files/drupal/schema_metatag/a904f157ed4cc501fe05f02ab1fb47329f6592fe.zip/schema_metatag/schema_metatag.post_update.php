<?php

/**
 * @file
 * Post update functions for Schema.org Metatag.
 */

/**
 * Read in new config schema with @id definitions.
 */
function schema_metatag_post_update_add_ids() {
  // Empty post update hook to trigger schema update.
}
