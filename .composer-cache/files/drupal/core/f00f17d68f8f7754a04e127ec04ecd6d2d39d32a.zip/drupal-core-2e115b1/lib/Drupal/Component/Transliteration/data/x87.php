<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'shu', 'xuan', 'feng', 'shen', 'shen', 'fu', 'xian', 'zhe', 'wu', 'fu', 'li', 'lang', 'bi', 'chu', 'yuan', 'you',
  0x10 => 'jie', 'dan', 'yan', 'ting', 'dian', 'tui', 'hui', 'wo', 'zhi', 'song', 'fei', 'ju', 'mi', 'qi', 'qi', 'yu',
  0x20 => 'jun', 'la', 'meng', 'qiang', 'si', 'xi', 'lun', 'li', 'die', 'tiao', 'tao', 'kun', 'han', 'han', 'yu', 'bang',
  0x30 => 'fei', 'pi', 'wei', 'dun', 'yi', 'yuan', 'suo', 'quan', 'qian', 'rui', 'ni', 'qing', 'wei', 'liang', 'guo', 'wan',
  0x40 => 'dong', 'e', 'ban', 'di', 'wang', 'can', 'yang', 'ying', 'guo', 'chan', 'ding', 'la', 'ke', 'jie', 'xie', 'ting',
  0x50 => 'mao', 'xu', 'mian', 'yu', 'jie', 'shi', 'xuan', 'huang', 'yan', 'bian', 'rou', 'wei', 'fu', 'yuan', 'mei', 'wei',
  0x60 => 'fu', 'ru', 'xie', 'you', 'qiu', 'mao', 'xia', 'ying', 'shi', 'chong', 'tang', 'zhu', 'zong', 'ti', 'fu', 'yuan',
  0x70 => 'kui', 'meng', 'la', 'du', 'hu', 'qiu', 'die', 'li', 'wo', 'yun', 'qu', 'nan', 'lou', 'chun', 'rong', 'ying',
  0x80 => 'jiang', 'ban', 'lang', 'pang', 'si', 'xi', 'ci', 'xi', 'yuan', 'weng', 'lian', 'sou', 'ban', 'rong', 'rong', 'ji',
  0x90 => 'wu', 'xiu', 'han', 'qin', 'yi', 'bi', 'hua', 'tang', 'yi', 'du', 'nai', 'he', 'hu', 'gui', 'ma', 'ming',
  0xA0 => 'yi', 'wen', 'ying', 'te', 'zhong', 'cang', 'sao', 'qi', 'man', 'tiao', 'shang', 'shi', 'cao', 'chi', 'di', 'ao',
  0xB0 => 'lu', 'wei', 'zhi', 'tang', 'chen', 'piao', 'qu', 'pi', 'yu', 'jian', 'luo', 'lou', 'qin', 'zhong', 'yin', 'jiang',
  0xC0 => 'shuai', 'wen', 'xiao', 'wan', 'zhe', 'zhe', 'ma', 'ma', 'guo', 'liu', 'mao', 'xi', 'cong', 'li', 'man', 'xiao',
  0xD0 => 'chang', 'zhang', 'mang', 'xiang', 'mo', 'zui', 'si', 'qiu', 'te', 'zhi', 'peng', 'peng', 'jiao', 'qu', 'bie', 'liao',
  0xE0 => 'pan', 'gui', 'xi', 'ji', 'zhuan', 'huang', 'fei', 'lao', 'jue', 'jue', 'hui', 'yin', 'chan', 'jiao', 'shan', 'nao',
  0xF0 => 'xiao', 'wu', 'chong', 'xun', 'si', 'chu', 'cheng', 'dang', 'li', 'xie', 'shan', 'yi', 'jing', 'da', 'chan', 'qi',
];
