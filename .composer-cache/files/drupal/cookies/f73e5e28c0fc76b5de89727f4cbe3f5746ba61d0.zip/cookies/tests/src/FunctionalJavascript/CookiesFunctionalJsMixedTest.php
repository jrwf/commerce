<?php

namespace Drupal\Tests\cookies\FunctionalJavascript;

/**
 * Class for testing submodule interactions.
 *
 * @todo Implement this class.
 *
 * @group cookies
 */
class CookiesFunctionalJsMixedTest extends CookiesFunctionalJsTestBase {

  /**
   * Dummy test, so the drupalcli won't throw an error.
   *
   * @todo DELTE ME, when tests are implemented in this class.
   */
  public function testDummy() {
    $this->assertEquals(1, 1);
  }

}
