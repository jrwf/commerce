<?php

namespace Drupal\cookies_asset_injector\Constants;

/**
 * Constants for the cookies_asset_injector module.
 */
class CookiesAssetInjectorConstants {

  const COOKIES_ASSET_INJECTOR_BLOCKED_SCRIPT_ID_PREFIX = 'cookies-asset-injector-blocked-script--';

}
