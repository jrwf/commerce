<?php

namespace Robo;

/**
 * @deprecated Use \Robo\Config\Config
 */
class Config extends \Robo\Config\Config
{
}
