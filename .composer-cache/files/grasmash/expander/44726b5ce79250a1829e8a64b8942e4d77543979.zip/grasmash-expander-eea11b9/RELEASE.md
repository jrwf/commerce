# Releasing

### Execute tests

    ./scripts/run-tests.sh

To quickly fix PHPCS issues:

    ./scripts/clean-code.sh
    

