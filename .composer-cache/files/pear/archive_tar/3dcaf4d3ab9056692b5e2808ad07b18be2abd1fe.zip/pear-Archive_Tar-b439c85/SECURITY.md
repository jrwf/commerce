# Reporting Security Issues

The Archive_Tar team and PEAR community take security bugs seriously. We appreciate your efforts to responsibly disclose your findings, and will make every effort to acknowledge your contributions.

To report a security issue, please use the GitHub Security Advisory ["Report a Vulnerability"](https://github.com/pear/Archive_Tar/security/advisories/new) tab.
